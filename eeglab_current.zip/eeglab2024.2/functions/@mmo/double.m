function a = double(a);

return;
