function varargout = arrow( varargin )

disp('The arrow function was removed from EEGLAB')
disp('because of lack of compatibility with Matlab 2019')
disp('An updated version of the function is available at')
disp('https://www.mathworks.com/matlabcentral/fileexchange/278-arrow')
